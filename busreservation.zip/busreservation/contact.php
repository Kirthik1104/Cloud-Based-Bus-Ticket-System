<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome to CRKT Bus Services</title>
<link rel="stylesheet" type="text/css" href="xres/css/style.css" />
<link rel="icon" type="image/png" href="xres/images/favicon.png" />
<link type="text/css" href="css/styles.css" rel="stylesheet" media="all" />
<style>
body {
  background-image: url('download.jpg');background-repeat: no-repeat;
  background-attachment: fixed; 
  background-size: 100% 100%;
}
</style>

</head>

<body>
<div id="wrapper">
	<div id="header">
    <h1><a href="index.php"></a></h1>
        <ul id="mainnav">
			<li><a href="index.php"style="color:white;">Home</a></li>
            <li><a href="gallery.php"style="color:white;">Gallery</a></li>
            <li><a href="history.php"style="color:white;">History</a></li>
            <li><a href="routes.php"style="color:white;">Routes</a></li>
            <li><a href="location.php"style="color:white;">location</a></li>
            <li class="current"><a href="contact.php"style="color:white;">Contact Us</a></li>
    	</ul>
	</div>
    <div id="content">
    	<div id="gallerycontainer">
			<div class="portfolio-area" style="margin:0 auto; padding:50px 20px 20px 20px; width:820px;">	
				<div id="contactleft">
					<b>SYRACUSE BUS</b><br>
(SYRACUSE TRANSPORT, INCORPORATED)<br>
Syracuse, Mainstreet<br>
- (01) 743-3809; 912-5354<br>
Telephone No: (607) 123-5894<br><br>

<b>BINGHAMTON BUS</b><br>
(BINGHAMTON TRANSPORT, INCORPORATED)<br>
Downtown, Binghamton<br>
- (01) 743-3809; 912-5354<br>
Telephone No: (607) 123-5894<br><br>


Binghamton Bus Terminal NY, Inc.<br>

Contact Numbers:<br>
<b>CRKT Bus Services +1 2345678 +1 12345678</b><br>

				</div><br>
				
               	<div class="column-clear"></div>
            </div>
			<div class="clearfix"></div>
        </div>
    </div>
    <div id="footer">
	<h4>+123456789 &bull; <a href="contact-us.php">CKRT Bus Services, Binghamton, New York 13905  </a></h4>
	<p>Hours of Operation&nbsp;&nbsp;&bull;&nbsp;&nbsp;Mon - Sun: 10:00 am - 12:00 am</p>
	<a href="index.php"><img src="output.png"  style="width:200px;
            height:200px"; alt="" /></a>
	<p>&copy; Copyright 2023 CKRT | All Rights Reserved</p>
</div>

</div>

</body>
</html>
